// 이주원

// 1번 문제
// -


// -

// 6번 문제
// : 까먹음

// 7번 문제
// :

// 8번 문제
// : while ?

// 9번 문제
// : 4

// 10번 문제
// : 2

// 11번 문제
// : Child

// 12번 문제
// : 4

// 13번 문제
// : 2

// 14번 문제
// : 업캐스팅

// 15번 문제
// : 2

// 16번 문제
// : 3

// 17번 문제
// : public

// 18번 문제
// : 13

// 19번
// : 어떤식으로 공부를 해야할 지 모르겠습니다.



// 20번
// :


import java.util.Scanner;

class Student {
    String name;
    int score;

     Student(String name, int score){
        this.name = name;
        this.score = score;
    }
};


public class test {
    public static void main(String[] args) {
        // 2번 문제
        int num1 = 10;
        double num2 = 3.5;

        double result = num1 + num2;

        System.out.println(result);

        // 3번 문제

        Scanner scanner = new Scanner(System.in);
        System.out.println("숫자를 입력하세요 :");
        int number = scanner.nextInt();
        if (number % 2 == 0) {
            System.out.println("입력하신 숫자는 짝수입니다.");
        } else {
            System.out.println("입력하신 숫자는 홀수입니다.");
        }
        scanner.close();
    }
    // 4번 문제



// 5번 문제
        // : class Test 바로 위에 클래스를 작성하고 main 메서드 내부에서 객체를 생성하세요.
}



